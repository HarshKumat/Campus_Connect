package com.example.thaparconnect.core.enums;

public enum UserType {
    USER, ADMIN;
}
